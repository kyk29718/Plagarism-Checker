import React, { useState, useCallback } from 'react';
import { FileText, Upload, BarChart2, AlertTriangle, Info } from 'lucide-react';

// Types
type FileData = {
  id: string;
  name: string;
  content: string;
};

type ComparisonResult = {
  file1Id: string;
  file2Id: string;
  similarityScore: number;
  matchedPhrases: string[];
};

function App() {
  const [files, setFiles] = useState<FileData[]>([]);
  const [results, setResults] = useState<ComparisonResult[]>([]);
  const [selectedAlgorithm, setSelectedAlgorithm] = useState<string>('cosine');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [preprocessOptions, setPreprocessOptions] = useState({
    removeWhitespace: true,
    removePunctuation: true,
    ignoreCase: true,
    removeComments: false,
  });

  // Handle file upload
  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFiles = event.target.files;
    if (!uploadedFiles) return;

    Array.from(uploadedFiles).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        setFiles((prevFiles) => [
          ...prevFiles,
          {
            id: `file-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            name: file.name,
            content,
          },
        ]);
      };
      reader.readAsText(file);
    });
  }, []);

  // Remove a file
  const removeFile = useCallback((id: string) => {
    setFiles((prevFiles) => prevFiles.filter((file) => file.id !== id));
    setResults((prevResults) => 
      prevResults.filter((result) => result.file1Id !== id && result.file2Id !== id)
    );
  }, []);

  // Preprocess text based on options
  const preprocessText = useCallback((text: string): string => {
    let processed = text;
    
    if (preprocessOptions.ignoreCase) {
      processed = processed.toLowerCase();
    }
    
    if (preprocessOptions.removePunctuation) {
      processed = processed.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, '');
    }
    
    if (preprocessOptions.removeWhitespace) {
      processed = processed.replace(/\s+/g, ' ').trim();
    }
    
    if (preprocessOptions.removeComments) {
      // Remove single line comments
      processed = processed.replace(/\/\/.*$/gm, '');
      // Remove multi-line comments
      processed = processed.replace(/\/\*[\s\S]*?\*\//g, '');
    }
    
    return processed;
  }, [preprocessOptions]);

  // Calculate cosine similarity
  const calculateCosineSimilarity = (text1: string, text2: string): number => {
    const words1 = text1.split(/\s+/);
    const words2 = text2.split(/\s+/);
    
    // Create word frequency maps
    const freqMap1: Record<string, number> = {};
    const freqMap2: Record<string, number> = {};
    
    words1.forEach(word => {
      freqMap1[word] = (freqMap1[word] || 0) + 1;
    });
    
    words2.forEach(word => {
      freqMap2[word] = (freqMap2[word] || 0) + 1;
    });
    
    // Get all unique words
    const uniqueWords = new Set([...Object.keys(freqMap1), ...Object.keys(freqMap2)]);
    
    // Calculate dot product and magnitudes
    let dotProduct = 0;
    let magnitude1 = 0;
    let magnitude2 = 0;
    
    uniqueWords.forEach(word => {
      const freq1 = freqMap1[word] || 0;
      const freq2 = freqMap2[word] || 0;
      
      dotProduct += freq1 * freq2;
      magnitude1 += freq1 * freq1;
      magnitude2 += freq2 * freq2;
    });
    
    magnitude1 = Math.sqrt(magnitude1);
    magnitude2 = Math.sqrt(magnitude2);
    
    // Avoid division by zero
    if (magnitude1 === 0 || magnitude2 === 0) return 0;
    
    return dotProduct / (magnitude1 * magnitude2);
  };

  // Calculate Jaccard similarity
  const calculateJaccardSimilarity = (text1: string, text2: string): number => {
    const words1 = new Set(text1.split(/\s+/));
    const words2 = new Set(text2.split(/\s+/));
    
    const intersection = new Set([...words1].filter(word => words2.has(word)));
    const union = new Set([...words1, ...words2]);
    
    return intersection.size / union.size;
  };

  // Find matching phrases (simple implementation)
  const findMatchingPhrases = (text1: string, text2: string, minLength: number = 4): string[] => {
    const words1 = text1.split(/\s+/);
    const words2 = text2.split(/\s+/);
    const matches: string[] = [];
    
    for (let i = 0; i <= words1.length - minLength; i++) {
      for (let j = 0; j <= words2.length - minLength; j++) {
        let matchLength = 0;
        while (
          i + matchLength < words1.length &&
          j + matchLength < words2.length &&
          words1[i + matchLength] === words2[j + matchLength]
        ) {
          matchLength++;
        }
        
        if (matchLength >= minLength) {
          matches.push(words1.slice(i, i + matchLength).join(' '));
          i += matchLength - 1;
          break;
        }
      }
    }
    
    return matches;
  };

  // Run plagiarism check
  const runPlagiarismCheck = useCallback(() => {
    if (files.length < 2) {
      alert('Please upload at least two files to compare.');
      return;
    }
    
    setIsProcessing(true);
    
    // Process in batches to avoid UI freezing
    setTimeout(() => {
      const newResults: ComparisonResult[] = [];
      
      for (let i = 0; i < files.length; i++) {
        for (let j = i + 1; j < files.length; j++) {
          const file1 = files[i];
          const file2 = files[j];
          
          const processedText1 = preprocessText(file1.content);
          const processedText2 = preprocessText(file2.content);
          
          let similarityScore: number;
          
          if (selectedAlgorithm === 'cosine') {
            similarityScore = calculateCosineSimilarity(processedText1, processedText2);
          } else {
            similarityScore = calculateJaccardSimilarity(processedText1, processedText2);
          }
          
          const matchedPhrases = findMatchingPhrases(processedText1, processedText2);
          
          newResults.push({
            file1Id: file1.id,
            file2Id: file2.id,
            similarityScore,
            matchedPhrases: matchedPhrases.slice(0, 5), // Limit to top 5 matches
          });
        }
      }
      
      setResults(newResults);
      setIsProcessing(false);
    }, 100);
  }, [files, preprocessText, selectedAlgorithm]);

  // Get file name by ID
  const getFileName = useCallback((id: string): string => {
    const file = files.find(f => f.id === id);
    return file ? file.name : 'Unknown file';
  }, [files]);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-indigo-700 text-white shadow-md">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <FileText size={28} />
              <h1 className="text-2xl font-bold">Plagiarism Checker</h1>
            </div>
            <div className="text-sm">
              <span className="opacity-75">Web-based Text Similarity Analysis</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Left panel - File upload */}
          <div className="md:col-span-1 bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <Upload size={20} className="mr-2 text-indigo-600" />
              Upload Files
            </h2>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select files to compare
              </label>
              <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md hover:border-indigo-500 transition-colors cursor-pointer">
                <div className="space-y-1 text-center">
                  <svg
                    className="mx-auto h-12 w-12 text-gray-400"
                    stroke="currentColor"
                    fill="none"
                    viewBox="0 0 48 48"
                    aria-hidden="true"
                  >
                    <path
                      d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02"
                      strokeWidth={2}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  <div className="flex text-sm text-gray-600">
                    <label
                      htmlFor="file-upload"
                      className="relative cursor-pointer bg-white rounded-md font-medium text-indigo-600 hover:text-indigo-500 focus-within:outline-none"
                    >
                      <span>Upload files</span>
                      <input
                        id="file-upload"
                        name="file-upload"
                        type="file"
                        className="sr-only"
                        multiple
                        accept=".txt,.java,.py,.js,.html,.css,.c,.cpp,.h,.cs,.php"
                        onChange={handleFileUpload}
                      />
                    </label>
                    <p className="pl-1">or drag and drop</p>
                  </div>
                  <p className="text-xs text-gray-500">
                    TXT, Java, Python, JavaScript, HTML, CSS, C/C++, C#, PHP
                  </p>
                </div>
              </div>
            </div>

            <div className="mb-6">
              <h3 className="text-md font-medium mb-2">Preprocessing Options</h3>
              <div className="space-y-2">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    className="rounded text-indigo-600 focus:ring-indigo-500 mr-2"
                    checked={preprocessOptions.ignoreCase}
                    onChange={(e) => setPreprocessOptions({
                      ...preprocessOptions,
                      ignoreCase: e.target.checked
                    })}
                  />
                  <span className="text-sm">Ignore case</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    className="rounded text-indigo-600 focus:ring-indigo-500 mr-2"
                    checked={preprocessOptions.removeWhitespace}
                    onChange={(e) => setPreprocessOptions({
                      ...preprocessOptions,
                      removeWhitespace: e.target.checked
                    })}
                  />
                  <span className="text-sm">Normalize whitespace</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    className="rounded text-indigo-600 focus:ring-indigo-500 mr-2"
                    checked={preprocessOptions.removePunctuation}
                    onChange={(e) => setPreprocessOptions({
                      ...preprocessOptions,
                      removePunctuation: e.target.checked
                    })}
                  />
                  <span className="text-sm">Remove punctuation</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    className="rounded text-indigo-600 focus:ring-indigo-500 mr-2"
                    checked={preprocessOptions.removeComments}
                    onChange={(e) => setPreprocessOptions({
                      ...preprocessOptions,
                      removeComments: e.target.checked
                    })}
                  />
                  <span className="text-sm">Remove code comments</span>
                </label>
              </div>
            </div>

            <div className="mb-6">
              <h3 className="text-md font-medium mb-2">Similarity Algorithm</h3>
              <div className="space-y-2">
                <label className="flex items-center">
                  <input
                    type="radio"
                    className="text-indigo-600 focus:ring-indigo-500 mr-2"
                    name="algorithm"
                    value="cosine"
                    checked={selectedAlgorithm === 'cosine'}
                    onChange={() => setSelectedAlgorithm('cosine')}
                  />
                  <span className="text-sm">Cosine Similarity</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    className="text-indigo-600 focus:ring-indigo-500 mr-2"
                    name="algorithm"
                    value="jaccard"
                    checked={selectedAlgorithm === 'jaccard'}
                    onChange={() => setSelectedAlgorithm('jaccard')}
                  />
                  <span className="text-sm">Jaccard Index</span>
                </label>
              </div>
            </div>

            <button
              className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              onClick={runPlagiarismCheck}
              disabled={files.length < 2 || isProcessing}
            >
              {isProcessing ? 'Processing...' : 'Run Plagiarism Check'}
            </button>
          </div>

          {/* Middle panel - Uploaded files */}
          <div className="md:col-span-1 bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <FileText size={20} className="mr-2 text-indigo-600" />
              Uploaded Files ({files.length})
            </h2>
            
            {files.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <p>No files uploaded yet.</p>
                <p className="text-sm mt-2">Upload files to begin comparison.</p>
              </div>
            ) : (
              <ul className="divide-y divide-gray-200">
                {files.map((file) => (
                  <li key={file.id} className="py-3">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <FileText size={18} className="text-gray-500 mr-2" />
                        <div>
                          <p className="text-sm font-medium text-gray-900 truncate max-w-[180px]">
                            {file.name}
                          </p>
                          <p className="text-xs text-gray-500">
                            {file.content.length} characters
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => removeFile(file.id)}
                        className="text-red-500 hover:text-red-700 text-sm"
                      >
                        Remove
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Right panel - Results */}
          <div className="md:col-span-1 bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <BarChart2 size={20} className="mr-2 text-indigo-600" />
              Results
            </h2>
            
            {results.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <p>No results yet.</p>
                <p className="text-sm mt-2">Run a check to see similarity scores.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {results.map((result, index) => (
                  <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="font-medium">Comparison #{index + 1}</h3>
                      <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                        result.similarityScore > 0.7 
                          ? 'bg-red-100 text-red-800' 
                          : result.similarityScore > 0.4 
                            ? 'bg-yellow-100 text-yellow-800' 
                            : 'bg-green-100 text-green-800'
                      }`}>
                        {Math.round(result.similarityScore * 100)}% Similar
                      </div>
                    </div>
                    
                    <div className="text-sm text-gray-600 mb-3">
                      <div className="flex items-center">
                        <FileText size={14} className="mr-1" />
                        <span className="truncate max-w-[200px]">{getFileName(result.file1Id)}</span>
                      </div>
                      <div className="flex items-center">
                        <FileText size={14} className="mr-1" />
                        <span className="truncate max-w-[200px]">{getFileName(result.file2Id)}</span>
                      </div>
                    </div>
                    
                    {result.matchedPhrases.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-gray-500 mb-1">
                          Common phrases:
                        </p>
                        <ul className="text-xs text-gray-600 list-disc pl-4">
                          {result.matchedPhrases.map((phrase, i) => (
                            <li key={i} className="truncate max-w-[250px]">"{phrase}"</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Information section */}
        <div className="mt-8 bg-white rounded-lg shadow-md p-6">
          <div className="flex items-start">
            <Info size={20} className="text-indigo-600 mr-3 mt-1 flex-shrink-0" />
            <div>
              <h3 className="text-lg font-medium mb-2">About This Plagiarism Checker</h3>
              <p className="text-gray-600 mb-4">
                This web-based plagiarism checker analyzes the similarity between text documents using advanced algorithms.
                It's designed to help identify potential instances of plagiarism or code duplication.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <h4 className="font-medium text-gray-800 mb-1">Cosine Similarity</h4>
                  <p className="text-gray-600">
                    Measures the cosine of the angle between two text vectors in a multi-dimensional space.
                    It focuses on the similarity in word frequency and is less affected by document length.
                  </p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-800 mb-1">Jaccard Index</h4>
                  <p className="text-gray-600">
                    Compares the similarity between finite sample sets by calculating the size of the intersection
                    divided by the size of the union of the sample sets.
                  </p>
                </div>
              </div>
              
              <div className="mt-4 bg-yellow-50 border-l-4 border-yellow-400 p-4">
                <div className="flex">
                  <AlertTriangle size={20} className="text-yellow-700 mr-2 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-yellow-700">
                      <span className="font-medium">Important:</span> This tool provides an estimate of text similarity and should be used as a guide only.
                      Always review the results manually to confirm actual instances of plagiarism.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-gray-800 text-white py-6">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <div className="flex items-center">
                <FileText size={20} className="mr-2" />
                <span className="font-semibold">Plagiarism Checker</span>
              </div>
              <p className="text-sm text-gray-400 mt-1">
                A web-based text similarity analysis tool
              </p>
            </div>
            <div className="text-sm text-gray-400">
              &copy; {new Date().getFullYear()} Plagiarism Checker. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;